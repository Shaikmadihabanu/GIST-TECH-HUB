"use client";

import { useState } from 'react';
import { Header } from '@/components/header';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Sparkles } from 'lucide-react';
import { askAssistant } from '@/ai/flows/assistant-flow';
import { useToast } from '@/hooks/use-toast';
import { Skeleton } from '@/components/ui/skeleton';

export default function AssistantPage() {
  const [prompt, setPrompt] = useState('');
  const [response, setResponse] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim()) return;

    setIsLoading(true);
    setResponse('');
    try {
      const result = await askAssistant({ question: prompt });
      setResponse(result.answer);
    } catch (error) {
      console.error('Error calling assistant flow:', error);
      toast({
        title: 'Error',
        description: 'Failed to get a response from the assistant. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <Header />
      <main className="container max-w-screen-lg mx-auto p-4 md:p-8">
        <div className="flex flex-col items-center text-center mb-8">
          <Sparkles className="h-12 w-12 text-primary mb-4" />
          <h1 className="text-3xl font-headline font-bold">AI Assistant</h1>
          <p className="text-muted-foreground mt-2">
            Ask me anything about your courses, campus life, or career advice!
          </p>
        </div>

        <Card className="max-w-2xl mx-auto">
          <CardContent className="p-6">
            <form onSubmit={handleSubmit} className="flex gap-2">
              <Input
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="e.g., Explain the concept of recursion"
                disabled={isLoading}
              />
              <Button type="submit" disabled={isLoading}>
                {isLoading ? 'Thinking...' : 'Ask'}
              </Button>
            </form>
          </CardContent>
        </Card>

        {(isLoading || response) && (
          <Card className="max-w-2xl mx-auto mt-6">
            <CardHeader>
              <CardTitle>Response</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="space-y-2">
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-3/4" />
                </div>
              ) : (
                <p className="whitespace-pre-wrap text-sm">{response}</p>
              )}
            </CardContent>
          </Card>
        )}
      </main>
    </>
  );
}

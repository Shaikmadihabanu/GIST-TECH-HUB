"use client";

import { useAuth } from '@/components/auth-provider';
import { Header } from '@/components/header';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Megaphone, Calendar, BookOpen, Youtube, Briefcase, Code } from 'lucide-react';
import Image from 'next/image';
import Link from 'next/link';

// Sample data
const announcements = [
  { id: 1, text: 'Mid-term examinations for 2nd and 3rd years will commence next week.' },
  { id: 2, text: 'Guest lecture on "AI in Modern Engineering" this Friday.' },
  { id: 3, text: 'Registrations open for the annual tech fest "Innovate 2024".' },
];

const events = [
  { id: 1, title: 'Presentation PPT', date: 'Aug 11', desc: 'Showcase your presentation skills.' },
  { id: 2, title: 'Technical Quiz', date: 'Aug 12', desc: 'A battle of brains and wit.' },
];

const resources = [
  { id: 1, title: 'Data Structures Notes', desc: 'Comprehensive notes for CSE students.', icon: BookOpen },
  { id: 2, title: 'Previous Year Papers', desc: 'Question papers for all branches.', icon: BookOpen },
  { id: 3, title: 'Internship Portals', desc: 'Links to top internship websites.', icon: Briefcase },
  { id: 4, title: 'Coding Challenge Platforms', desc: 'Sharpen your skills for placements.', icon: Code },
];

const placementVideos = [
    { id: 1, title: 'How to Crack FAANG Interviews', thumbnailUrl: 'https://placehold.co/400x225.png', videoUrl: 'https://www.youtube.com', hint: 'interview computer' },
    { id: 2, title: 'Resume Building Workshop', thumbnailUrl: 'https://placehold.co/400x225.png', videoUrl: 'https://www.youtube.com', hint: 'resume document' },
    { id: 3, title: 'Ace Your Technical Rounds', thumbnailUrl: 'https://placehold.co/400x225.png', videoUrl: 'https://www.youtube.com', hint: 'code circuit' },
];


export default function Dashboard() {
  const { user, profile } = useAuth();

  if (!user || !profile) {
    // AuthProvider handles redirection, but this is a safeguard.
    return null;
  }

  return (
    <>
      <Header />
      <main className="container max-w-screen-2xl mx-auto p-4 md:p-8">
        <div className="space-y-4 mb-8">
          <h1 className="text-3xl font-headline font-bold">Welcome, {user.email.split('@')[0]}!</h1>
          <p className="text-muted-foreground">Here's your personalized dashboard for {profile.branch}, Year {profile.year}.</p>
        </div>

        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {/* Announcements Card */}
          <Card className="lg:col-span-2">
            <CardHeader className="flex flex-row items-center gap-4">
              <Megaphone className="h-6 w-6 text-primary" />
              <CardTitle>Campus Announcements</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-4">
                {announcements.map((item) => (
                  <li key={item.id} className="text-sm border-l-2 border-primary pl-4">{item.text}</li>
                ))}
              </ul>
            </CardContent>
          </Card>

          {/* Upcoming Events Card */}
          <Card>
            <CardHeader className="flex flex-row items-center gap-4">
              <Calendar className="h-6 w-6 text-primary" />
              <CardTitle>Upcoming Events</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {events.map((event) => (
                  <div key={event.id} className="flex items-start gap-4">
                    <div className="flex flex-col items-center justify-center p-2 bg-muted rounded-md min-w-[60px]">
                      <span className="text-xs font-bold">{event.date.split(' ')[0]}</span>
                      <span className="font-bold text-lg text-primary">{event.date.split(' ')[1]}</span>
                    </div>
                    <div>
                      <h4 className="font-semibold">{event.title}</h4>
                      <p className="text-sm text-muted-foreground">{event.desc}</p>
                    </div>
                  </div>
                ))}
                 <div className="mt-4 p-4 bg-muted/50 border border-dashed rounded-lg text-center">
                  <p className="font-semibold text-muted-foreground">Stay tuned for more updates!</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          {/* Placement Prep Card */}
          <Card className="lg:col-span-3">
            <CardHeader className="flex flex-row items-center gap-4">
              <Youtube className="h-6 w-6 text-primary" />
              <CardTitle>Placement Prep Videos</CardTitle>
            </CardHeader>
            <CardContent className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {placementVideos.map((video) => (
                <Link key={video.id} href={video.videoUrl} target="_blank" rel="noopener noreferrer" className="group block">
                  <Card className="overflow-hidden transition-all duration-300 hover:shadow-lg hover:-translate-y-1">
                    <CardContent className="p-0">
                      <div className="relative aspect-video">
                        <Image 
                          src={video.thumbnailUrl} 
                          alt={video.title} 
                          fill
                          className="object-cover"
                          data-ai-hint={video.hint}
                          />
                      </div>
                      <div className="p-4">
                        <h4 className="font-semibold truncate group-hover:text-primary">{video.title}</h4>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </CardContent>
          </Card>

          {/* Department Image Card */}
          <Card className="relative overflow-hidden h-64">
             <Image 
                src="https://placehold.co/600x400.png"
                alt="Department Building"
                fill
                className="object-cover transition-transform duration-300 hover:scale-105"
                data-ai-hint="university campus"
             />
             <div className="absolute inset-0 bg-black/50 flex items-end p-4">
                <h3 className="text-white text-xl font-bold">Department of {profile.branch}</h3>
             </div>
          </Card>

          {/* Study Resources Card */}
          <Card className="lg:col-span-2">
            <CardHeader className="flex flex-row items-center gap-4">
              <BookOpen className="h-6 w-6 text-primary" />
              <CardTitle>Future Links &amp; Resources</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 sm:grid-cols-2">
                {resources.map((res) => (
                   <div key={res.id} className="flex items-start gap-4 p-4 bg-muted rounded-lg hover:bg-muted/80 transition-colors">
                      <res.icon className="h-6 w-6 text-primary mt-1 flex-shrink-0" />
                      <div>
                        <h4 className="font-semibold">{res.title}</h4>
                        <p className="text-sm text-muted-foreground">{res.desc}</p>
                      </div>
                   </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </>
  );
}

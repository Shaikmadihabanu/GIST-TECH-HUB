import Link from 'next/link';

export function Logo() {
  return (
    <Link href="/" className="flex items-center" aria-label="GIST TECH HUB Home">
      <span className="font-headline text-2xl sm:text-3xl font-bold text-primary [text-shadow:0_0_8px_hsl(var(--primary))]">GIST TECH HUB</span>
    </Link>
  );
}

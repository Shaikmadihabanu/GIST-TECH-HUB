"use client";

import { usePathname, useRouter } from 'next/navigation';
import type { ReactNode } from 'react';
import { createContext, useContext, useEffect, useState } from 'react';

type User = {
  email: string;
};

type Profile = {
  branch: string;
  year: string;
};

type AuthContextType = {
  user: User | null;
  profile: Profile | null;
  loading: boolean;
  login: (email: string) => void;
  logout: () => void;
  setProfile: (profile: Profile) => void;
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfileState] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const router = useRouter();
  const pathname = usePathname();

  useEffect(() => {
    // Simulate checking auth state from localStorage
    try {
      const storedUser = localStorage.getItem('gist_user');
      const storedProfile = localStorage.getItem('gist_profile');
      if (storedUser) {
        setUser(JSON.parse(storedUser));
      }
      if (storedProfile) {
        setProfileState(JSON.parse(storedProfile));
      }
    } catch (error) {
      console.error('Failed to parse auth from localStorage', error);
      localStorage.removeItem('gist_user');
      localStorage.removeItem('gist_profile');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (loading) return;

    const publicPaths = ['/login', '/signup'];
    const isPublicPath = publicPaths.includes(pathname);
    const isProfileSetupPath = pathname === '/profile-setup';

    if (!user && !isPublicPath) {
      router.push('/login');
    } else if (user && isPublicPath) {
      router.push('/');
    } else if (user && !profile && !isProfileSetupPath) {
      router.push('/profile-setup');
    } else if (user && profile && isProfileSetupPath) {
      router.push('/');
    }
  }, [user, profile, loading, pathname, router]);

  const login = (email: string) => {
    const newUser = { email };
    setUser(newUser);
    localStorage.setItem('gist_user', JSON.stringify(newUser));
    router.push('/profile-setup');
  };

  const logout = () => {
    setUser(null);
    setProfileState(null);
    localStorage.removeItem('gist_user');
    localStorage.removeItem('gist_profile');
    router.push('/login');
  };

  const setProfile = (newProfile: Profile) => {
    setProfileState(newProfile);
    localStorage.setItem('gist_profile', JSON.stringify(newProfile));
    router.push('/');
  };

  const value = { user, profile, loading, login, logout, setProfile };

  if (loading || (!user && !['/login', '/signup'].includes(pathname)) || (user && !profile && pathname !== '/profile-setup') ) {
    return (
      <div className="flex h-screen w-full items-center justify-center bg-background">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-solid border-primary border-t-transparent"></div>
      </div>
    );
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

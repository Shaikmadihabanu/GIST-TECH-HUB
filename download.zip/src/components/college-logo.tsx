export function CollegeLogo({ className }: { className?: string }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 100 90"
      className={className}
      width="48"
      height="42"
    >
      {/* Shield */}
      <path d="M5 5 H 95 L 95 50 C 95 75, 50 85, 50 85 C 50 85, 5 75, 5 50 Z" fill="#F97316" />

      {/* Sunburst Rays */}
      <g transform="translate(50, 45) scale(0.8)">
        {Array.from({ length: 24 }).map((_, i) => (
          <line
            key={i}
            x1="0"
            y1="0"
            x2="0"
            y2="-40"
            stroke="white"
            strokeWidth="3.5"
            transform={`rotate(${i * 15})`}
          />
        ))}
      </g>
      
      {/* Green Symbol */}
      <path
        d="M50 25 C 40 45, 35 55, 40 68 M50 25 C 60 45, 65 55, 60 68 M45 55 C 50 48, 55 48, 55 55"
        stroke="#10B981"
        strokeWidth="7"
        fill="none"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

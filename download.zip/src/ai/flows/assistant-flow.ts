'use server';
/**
 * @fileOverview A simple AI assistant flow.
 * - askAssistant - A function that takes a question and returns an answer.
 * - AssistantInput - The input type for the askAssistant function.
 * - AssistantOutput - The return type for the askAssistant function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'zod';

export const AssistantInputSchema = z.object({
    question: z.string().describe('The question to ask the assistant.'),
});
export type AssistantInput = z.infer<typeof AssistantInputSchema>;

export const AssistantOutputSchema = z.object({
    answer: z.string().describe("The assistant's answer."),
});
export type AssistantOutput = z.infer<typeof AssistantOutputSchema>;


export async function askAssistant(input: AssistantInput): Promise<AssistantOutput> {
  return assistantFlow(input);
}

const assistantPrompt = ai.definePrompt({
    name: 'assistantPrompt',
    input: { schema: AssistantInputSchema },
    output: { schema: AssistantOutputSchema },
    prompt: `You are a helpful AI assistant for GIST TECH HUB, a platform for students of Geethanjali Institute of Science and Technology. Your goal is to be helpful and provide concise, accurate information. Answer the user's question.

    Question: {{{question}}}`,
});


const assistantFlow = ai.defineFlow(
  {
    name: 'assistantFlow',
    inputSchema: AssistantInputSchema,
    outputSchema: AssistantOutputSchema,
  },
  async (input) => {
    const { output } = await assistantPrompt(input);
    return output!;
  }
);
